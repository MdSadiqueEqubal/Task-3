
// Quiz Data
const quizData = [
  { q: "1. What is the full form of HTML", options: ["Hyper Text Markup Language", "Home Tool Markup Language", "Hyperlinks Text", "HighText Machine Language"], answer: 0 },
  { q: "2. Where is CSS used?", options: ["Database", "Styling Webpages", "Server", "Networking"], answer: 1 },
  { q: "3. What is JavaScript mainly used for?", options: ["Styling", "Interactivity", "Database", "Security"], answer: 1 },
  { q: "4. React is based on which language?", options: ["Python", "C++", "JavaScript", "Java"], answer: 2 },
  { q: "5. What type of database is MongoDB?", options: ["Relational DB", "NoSQL", "Spreadsheet", "File Storage"], answer: 1 },
  { q: "6. Which property is used to give color in CSS?", options: ["background-color", "font-style", "align", "border"], answer: 0 }
];

let currentQ = 0;
let score = 0;

function loadQuestion() {
  const container = document.getElementById("quiz-container");
  if (currentQ >= quizData.length) {
    container.innerHTML = `<h3>Quiz Finished! 🎉</h3>`;
    document.getElementById("save-score").style.display = "inline-block";
    return;
  }

  const qData = quizData[currentQ];
  container.innerHTML = `
    <div class="quiz-question"><h3>${qData.q}</h3></div>
    ${qData.options.map((opt, i) => `<button class="option" onclick="checkAnswer(${i})">${opt}</button>`).join("")}
  `;
}

function checkAnswer(selected) {
  const qData = quizData[currentQ];
  const options = document.querySelectorAll(".option");

  if (selected === qData.answer) {
    options[selected].classList.add("correct");
    score += 10;
    document.getElementById("score").innerText = "Score: " + score;
  } else {
    options[selected].classList.add("wrong");
    options[qData.answer].classList.add("correct");
  }

  setTimeout(() => {
    currentQ++;
    loadQuestion();
  }, 1000);
}

loadQuestion();

// Save Score
document.getElementById("save-score").addEventListener("click", () => {
  alert("Your Score (" + score + ") saved successfully! 🎯");
});

// Jokes Section
const jokes = [
  "Why don’t programmers like nature? Too many bugs 🐛",
  "Why did the developer go broke? Because he used up all his cache 💸",
  "Debugging: Being the detective in a crime movie where you are also the murderer 🔍",
  "Why do Java developers wear glasses? Because they don’t C# 🤓",
  "Programmer’s diet: Pizza, Coffee & Bugs 🍕☕🐞"
];

document.getElementById("joke-btn").addEventListener("click", () => {
  const randomJoke = jokes[Math.floor(Math.random() * jokes.length)];
  document.getElementById("joke").innerText = randomJoke;
});